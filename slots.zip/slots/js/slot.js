let currentDate = dayjs().format('MM/DD/YYYY');
let availability = [];

/*
* [{
* date : 02/14/2021 , slots: [ {
        'firstName' : 'Blah',
        'lastName' : 'blah',
        'email' : 'blah@blah.com',
        'phone' : '1232323123',
        'parayanaTime' : '7:20'
    },  {
        'firstName' : 'Blah',
        'lastName' : 'blah',
        'email' : 'blah@blah.com',
        'phone' : '1232323123',
        'parayanaTime' : 'Tue, 14 Feb 2021 10:20:30 GMT'
    }, {
        'firstName' : 'Blah',
        'lastName' : 'blah',
        'email' : 'blah@blah.com',
        'phone' : '1232323123',
        'parayanaTime' : 'Tue, 14 Feb 2021 11:20:30 GMT'
    }]
* }
*
* ]
* */

let slots = [];
(function($) {
    let setAvailabilityTimes = function() {
        let times = [];
        let x = 40; //minutes interval
        let tt = 7 * 60; // start time
        let ap = [' AM', ' PM']; // AM-PM
        let startArr = [7, 20];
        let endArr = [10, 24];
        //loop to increment the time and push results in array
        for (let i = 0; tt < 24 * 60; i++) {
            let hh = Math.floor(tt / 60); // getting hours of day in 0-24 format
            let mm = (tt % 60); // getting minutes of the hour in 0-55 format
            if ((hh >= startArr[0] && hh <= endArr[0]) || (hh >= startArr[1] && hh <= endArr[1])) {
                let value = ("0" + (hh % 12)).slice(-2) + ':' + ("0" + mm).slice(-2) + ap[Math.floor(hh / 12)]; // pushing data in array in AM/PM format
                times.push(value);
            }
            tt = tt + x;
        }
        for (let i=0;i<7;i++) {
            let date = dayjs().add(i, 'day').format('MM/DD/YYYY');
            times.forEach((time) => {
                let available = true;
                console.log((new Date()).getHours() );
                if (currentDate === date && ((new Date()).getHours() > parseInt(convertTime12to24(time)))) {
                    available = false;
                }
                let slot = {
                    time: time,
                    available: available
                };
                slots.push(slot);
            });
            let slotDetails = {
                date : date,
                slots : slots
            };
            slots = []; // resetting slots array for each day
            availability.push(slotDetails);
        }
        console.log(availability);
    };
    setAvailabilityTimes();
  $('#picker').markyourcalendar({
    slots: {
        'firstName' : 'Blah',
        'lastName' : 'blah',
        'email' : 'blah@blah.com',
        'phone' : '1232323123',
        'parayanaTime' : 'Tue, 8 Feb 2021 09:20:30 GMT'
    },
    availability: availability,
    startDate: new Date(currentDate),
    onClick: function(ev, data) {
      // data is a list of datetimes
      let d = data[0].split(' ')[0];
      let t = data[0].split(' ')[1]+data[0].split(' ')[2];
      $('#selected-date').html(d);
      $('#selected-time').html(t);
    }
  });
})(jQuery);

function createTimeRanges() {
    let slotDetails = {
        time: '',
    }
}
console.log(formatAMPM(new Date()));
console.log(convertTime12to24("8:20 PM"));
//using your function (passing in date)
function formatAMPM(date) {
    let hours = date.getHours();
    let minutes = date.getMinutes();
    // gets AM/PM
    let ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+ minutes : minutes;
    let time = hours + ':' + minutes + ' ' + ampm;

    return time;
}

function convertTime12to24(time12h) {
    const [time, modifier] = time12h.split(' ');
    let [hours, minutes] = time.split(':');
    if (hours === '12') {
        hours = '00';
    }

    if (modifier === 'PM') {
        hours = parseInt(hours, 10) + 12;
    }

    return `${hours}`;
}

