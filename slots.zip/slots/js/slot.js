let currentDate = dayjs().format('YYYY/MM/DD');


(function($) {
  $('#picker').markyourcalendar({
    slots: {
        'firstName' : 'Blah',
        'lastName' : 'blah',
        'email' : 'blah@blah.com',
        'phone' : '1232323123',
        'parayanaTime' : 'Tue, 8 Feb 2021 09:20:30 GMT'
    },
    availability: [
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20'],
      ['7:00 - 7:40', '7:40 - 8:20', '8:20 - 9:00', '9:00 - 9:40', '9:40 - 10:20']
    ],
    startDate: new Date(currentDate),
    onClick: function(ev, data) {
      // data is a list of datetimes
      var d = data[0].split(' ')[0];
      var t = data[0].split(' ')[1];
      $('#selected-date').html(d);
      $('#selected-time').html(t);
    },
  });
})(jQuery);




